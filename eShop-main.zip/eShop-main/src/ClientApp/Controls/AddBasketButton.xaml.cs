﻿namespace eShop.ClientApp.Controls;

public partial class AddBasketButton : Grid
{
    public AddBasketButton()
    {
        InitializeComponent();
    }
}
