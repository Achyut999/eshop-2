﻿namespace eShop.ClientApp.Services.Theme;

public class Theme : ITheme
{
    public void SetStatusBarColor(Color color, bool darkStatusBarTint)
    {
    }
}
