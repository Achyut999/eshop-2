﻿namespace eShop.ClientApp.Services.Common;

public static class Common
{
    public static int MockCatalogItemId01 = 1;
    public static int MockCatalogItemId02 = 2;
    public static int MockCatalogItemId03 = 3;
    public static int MockCatalogItemId04 = 4;
    public static int MockCatalogItemId05 = 5;

    public static int MockCampaignId01 = 1;
    public static int MockCampaignId02 = 2;
}
