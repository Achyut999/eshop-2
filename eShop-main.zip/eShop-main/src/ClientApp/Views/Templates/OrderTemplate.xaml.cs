﻿namespace eShop.ClientApp.Views.Templates;

public partial class OrderTemplate : ContentView
{
    public OrderTemplate()
    {
        InitializeComponent();
    }
}
