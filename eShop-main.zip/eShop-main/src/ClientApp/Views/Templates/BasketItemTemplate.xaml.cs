﻿namespace eShop.ClientApp.Views.Templates;

public partial class BasketItemTemplate
{
    public BasketItemTemplate()
    {
        InitializeComponent();
    }
}
