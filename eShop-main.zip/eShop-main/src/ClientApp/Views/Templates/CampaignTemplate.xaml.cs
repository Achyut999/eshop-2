﻿namespace eShop.ClientApp.Views.Templates;

public partial class CampaignTemplate : ContentView
{
    public CampaignTemplate()
    {
        InitializeComponent();
    }
}
