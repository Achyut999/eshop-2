﻿namespace eShop.ClientApp.Views.Templates;

public partial class OrderItemTemplate : ContentView
{
    public OrderItemTemplate()
    {
        InitializeComponent();
    }
}
