﻿global using eShop.ClientApp.ViewModels;
global using CommunityToolkit.Mvvm.ComponentModel;
global using CommunityToolkit.Mvvm.Input;
