﻿namespace eShop.ClientApp.Validations;

public interface IValidity
{
    bool IsValid { get; }
}
