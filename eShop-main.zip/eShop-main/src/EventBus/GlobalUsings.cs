﻿global using System.Text.Json.Serialization;
global using eShop.EventBus.Events;
