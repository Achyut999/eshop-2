﻿namespace eShop.Ordering.Domain.Seedwork;

public interface IAggregateRoot { }


