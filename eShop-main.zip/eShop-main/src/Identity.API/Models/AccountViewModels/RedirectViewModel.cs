﻿namespace eShop.Identity.API.Models.AccountViewModels
{
    public class RedirectViewModel
    {
        public string RedirectUrl { get; set; }
    }
}
