﻿namespace eShop.Identity.API.Models.ManageViewModels
{
    public record FactorViewModel
    {
        public string Purpose { get; init; }
    }
}
