﻿global using Microsoft.AspNetCore.Builder;
global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.Hosting;
global using Microsoft.Extensions.Logging;
global using eShop.OrderProcessor.Extensions;
global using eShop.OrderProcessor.Services;
global using eShop.ServiceDefaults;
